<?php

class Controller_map extends Controller {
  
}