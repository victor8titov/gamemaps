<?php

class Controller {
	
	public $model;
	public $view;

	protected $method = ''; //GET|POST|PUT|DELETE
	
	function __construct() {

	}
	
	abstract protected function indexAction();
	abstract protected function viewAction();
	abstract protected function createAction();
	abstract protected function updateAction();
	abstract protected function deleteAction();
}
