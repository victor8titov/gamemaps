<?php

class Model
{
	// метод выборки данных
	public function get_data() {}
}