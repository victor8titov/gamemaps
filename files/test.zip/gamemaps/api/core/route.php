<?php

// try {
//   $api = new usersApi();
//   echo $api->run();
// } catch (Exception $e) {
//   echo json_encode(Array('error' => $e->getMessage()));
// }

class Route {
  
  static $method = '';
  static $requestUri = [];
  static $requestParams = [];
  
  static function start() {
    $controller_name = '';

    self::$requestUri = explode('/', trim($_SERVER['REQUEST_URI'],'/'));
    if (!empty(self::$requestUri[1])) {
      $controller_name = self::$requestUri[1];
    }

    self::$requestParams = $_REQUEST;
    
    //Определение метода запроса
    self::$method = $_SERVER['REQUEST_METHOD'];
    if (self::$method == 'POST' && array_key_exists('HTTP_X_HTTP_METHOD', $_SERVER)) {
      if ($_SERVER['HTTP_X_HTTP_METHOD'] == 'DELETE') {
          self::$method = 'DELETE';
      } else if ($_SERVER['HTTP_X_HTTP_METHOD'] == 'PUT') {
          self::$method = 'PUT';
      } else {
          throw new Exception("Unexpected Header");
      }
    }
    
    // подцепляем файл с классом контроллера
		$controller_file = strtolower($controller_name).'.php';
		$controller_path = "api/controllers/".$controller_file;
		if(file_exists($controller_path))
		{
			include "api/controllers/".$controller_file;
		}
		else
		{
			throw new Exception("Unexpected controller");
    }
    
    // создаем контроллер
    $controller_name = 'Controller_'.$controller_name;
    $controller = new $controller_name;
    $action = self::getAction();

    if (method_exists($controller, $action)) {
      $controller->$action();
    } else {
      throw new RuntimeException('Invalid Method', 405);
    }

  }

  protected function getAction() {
    $method = self::$method;
    switch ($method) {
        case 'GET':
            if(self::$requestUri){
                return 'viewAction';
            } else {
                return 'indexAction';
            }
            break;
        case 'POST':
            return 'createAction';
            break;
        case 'PUT':
            return 'updateAction';
            break;
        case 'DELETE':
            return 'deleteAction';
            break;
        default:
            return null;
    }
  }
}