<?php

class Controller {
	
	public $model;
	public $view;

	function __construct() {
		$this->view = new View();
	}
	
	protected function indexAction() {}
	protected function viewAction() {}
	protected function createAction() {}
	protected function updateAction() {}
	protected function deleteAction() {}

}

