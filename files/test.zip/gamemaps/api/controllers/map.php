<?php

class Controller_map extends Controller {
  function indexAction() {
    echo 'method map';
  }

	function viewAction() {
    echo 'method map';
  }

	function createAction() {
    echo 'method map';
  }

	function updateAction() {
    echo 'method map';
  }

	function deleteAction() {
    echo 'method map';
  }

}